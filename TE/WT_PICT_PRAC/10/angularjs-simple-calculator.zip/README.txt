A Pen created at CodePen.io. You can find this one at https://codepen.io/rabidgadfly/pen/AmJIf.

 AngularJS simple calculator as mentioned in http://rabidgadfly.com/2012/12/angularjs-simple-calculator/